sum = 0

for i in range(0,10):
    num = eval(input("Enter a number:"))
    sum += num
print(f"The sum of all the given number is: {sum}")    