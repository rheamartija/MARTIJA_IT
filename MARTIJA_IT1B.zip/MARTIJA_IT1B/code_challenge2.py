name = input ("What is your name?")

print("\t\t\t\t\t\t\t           *\n\t\t\t\t\t\t\t       *   *   *\n\t\t\t\t\t\t\t   *   *   *   *   *\n\t\t\t\t\t\t\t*      Hi!  "   +name+   "       *\n\t\t\t\t\t\t\t   *   *   *   *   *\n\t\t\t\t\t\t\t       *   *   *\n\t\t\t\t\t\t\t           * \nRhea Charicce A. Martija \nBSIT-1B")