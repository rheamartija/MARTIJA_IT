#listing

fruits = ["Avocado","Mango","Orange","Rambutan"]

print(f"My favorite fruits is {fruits[3]}.")

#to add another item to the list
fruits.append("Apple")
print(fruits)

#to insert an item to a specific index in the list
fruits.insert(2,"Watermelon")
print(fruits)

#to delete an item on a specifc index in the lsit
fruits.remove("Mango")
print(fruits)