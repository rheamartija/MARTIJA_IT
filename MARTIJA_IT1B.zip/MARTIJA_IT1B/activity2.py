#comments are used to convey information about your code
#comments are ignore by the compiler which is python,nevertheless still an
#important part of the program

comments = 1

print("comments are used to convey information about your code")
print("comments are ignore by the compiler which is python,nevertheless still an important part of the program")