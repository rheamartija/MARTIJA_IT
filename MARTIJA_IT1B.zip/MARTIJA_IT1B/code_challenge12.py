for r in range(1,6):
    for h in range(6, r, -1):
        print(" ", end= " ")    
    for e in range(1, r , 1):
        print("*", end= " ")            
    for a in range(1, r , 1):
        print("*",end= " ")
    print()           

for x in range (1, 5):
    for y in range(1, x , +1):
        print(" " , end= " ")
    for z in range(5, x , -1):
        print(" " , end= " ")
    for t in range (6, a , -1):
       print("*" , end= " ")
    
    print()    