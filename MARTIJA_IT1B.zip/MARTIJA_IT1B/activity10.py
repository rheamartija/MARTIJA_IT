for a in range(1 , 11):
    print ( a , end= " ")
    for x in range (1 , 11):
        print( "*" , end= " ")
    print()    