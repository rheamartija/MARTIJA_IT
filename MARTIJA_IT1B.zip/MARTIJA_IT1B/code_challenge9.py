for r in range (1, 11):
    for h in range(1, r + 1):
        print(" " , end= " ")
    for e in range(11 , r , -1):
        print("*" , end= " ")
    for a in range (11 , r , -1 ):
       print("*" , end= " ")
    
    print()    




