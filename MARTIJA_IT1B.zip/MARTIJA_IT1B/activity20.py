#modules

modules = 1

from activity18 import greet
print("----------")

from activity19 import fruits
print("----------")