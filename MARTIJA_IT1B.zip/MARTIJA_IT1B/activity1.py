
greet = 1

print("hello world")