#assignment operations
# += incrementor

#create a program that will asign 12 to the value of 'x'

x = 10
print(x)

x = x + 10
print(x)

x = x + 20
print(x)

#simplified version

x += 10
print(x)

x *= 3
print(x)