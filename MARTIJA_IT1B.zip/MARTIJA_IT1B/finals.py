from activity1 import greet
print("----------")

from activity2 import comments
print("----------")

from activity3 import name
print("----------")

from activity4 import fah
print("----------")

from activity5 import x 
print("----------")

from activity6  import password
print("----------")

from activity7 import prelim
print("----------")

from activity8 import sum
print("----------")

from activity9 import num
print("----------")

from activity10 import a
print("----------")

from activity11 import isRepeat
print("----------")

from activity12 import x
print("----------")

from activity13 import x
print("----------")

from activity14 import num
print("----------")

from activity15 import con
print("----------")

from activity16 import sum
print("----------")

from activity17 import greet
print("----------")

from activity18 import greet
print("----------")

from activity19 import fruits
print("----------")

from activity20 import modules
print("----------")

from code_challenge1 import tri
print("----------")

from code_challenge2 import name
print("----------")

from code_challenge3 import num1
print("----------")

from code_challenge4 import name
print("----------")

from code_challenge5 import prelim
print("----------")

from code_challenge6 import age
print("----------")

from code_challenge7 import grocery
print("----------")

from code_challenge8 import sum
print("----------")

from code_challenge9 import r
print("----------")

from code_challenge10 import h
print("----------")

from code_challenge11 import e
print("----------")

from code_challenge12 import a
print("----------")

from code_challenge13 import con
print("----------")

from code_challenge14 import Bank
print("----------")